# ⚠️Do not use this as a open project⚠️
There are still a lot of vulnerabilities


# EasyChat
ws server must be in a separated folder instead in the react one
